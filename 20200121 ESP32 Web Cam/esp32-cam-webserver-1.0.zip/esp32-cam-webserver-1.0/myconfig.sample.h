// Rename this example to 'mywifi.h' and fill in your details.
// This is in the '.gitignore' file, which helps to keep details secret.

const char* ssid = "my-access-point-ssid";
const char* password = "my-access-point-password";


// Optionally give the camera a name for the web interface 
//  (nb: this is not the network hostname)

#define CAM_NAME "my-awesome-webcam"
