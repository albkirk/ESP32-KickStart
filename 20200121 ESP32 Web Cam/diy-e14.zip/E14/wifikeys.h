const char *ssid =     "Network";         // Put your SSID here
const char *password = "Password";      // Put your PASSWORD here
